import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { map } from 'rxjs/operators';
import { Configuration } from './assets/config/config';

@Injectable({
  providedIn: 'root'
})
export class ConfigServiceService {
  private config: any;
  constructor(private http: HttpClient) { }
  load(url: string) {
    return new Promise((resolve) => {
      this.http.get(url).pipe(map(res => res))
        .subscribe(config => {
          this.config = config;
          resolve();
        });
    });

  }
  getConfiguration(): Configuration {
    return this.config;
  }

  setConfigDetails(baseurl) {
    this.config.BASE_API_URL = baseurl;
  }
}

import { BrowserModule } from '@angular/platform-browser';
import { NgModule, CUSTOM_ELEMENTS_SCHEMA, APP_INITIALIZER } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HeaderComponent } from './components/header/header.component';
import { DonateBloodComponent } from './components/donateblood/donateblood.component';
import { FindBloodComponent } from './components/findblood/findblood.component';
import { NgxSpinnerModule } from 'ngx-spinner';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { DatePipe, CommonModule, LocationStrategy, HashLocationStrategy, PathLocationStrategy } from '@angular/common';
import { JwPaginationModule } from 'jw-angular-pagination';
import { BloodDonationService } from './shared/service/blood.donation.service';
import { ActivitiesComponent } from './components/activities/activities.component';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { FooterComponent } from './components/footer/footer.component';
import { ConfigLoader } from 'src/config.loader';
import { ConfigServiceService } from 'src/config-service.service';
import { SpreadsheetAllModule } from '@syncfusion/ej2-angular-spreadsheet';
@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    DonateBloodComponent,
    FindBloodComponent,
    ActivitiesComponent,
    FooterComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    NgxSpinnerModule,
    BrowserAnimationsModule,
    NgbModule,
    FormsModule,
    HttpClientModule,
    CommonModule,
    JwPaginationModule,
    SpreadsheetAllModule
  ],
  providers: [DatePipe, BloodDonationService, , { provide: LocationStrategy, useClass: PathLocationStrategy },
    {
      provide: APP_INITIALIZER,
      useFactory: ConfigLoader,
      deps: [ConfigServiceService],
      multi: true,
    },],
  bootstrap: [AppComponent]
})
export class AppModule { }

import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HeaderComponent } from './components/header/header.component';
import { HomeComponent } from './components/home/home.component';
import { DonateBloodComponent } from './components/donateblood/donateblood.component';
import { FindBloodComponent } from './components/findblood/findblood.component';
import { ActivitiesComponent } from './components/activities/activities.component';


const routes: Routes = [
  { path: '', component: HomeComponent },
  { path: 'donateblood', component: DonateBloodComponent },
  { path: 'home', component: HomeComponent },
  { path: 'findblood', component: FindBloodComponent },
  { path: 'aboutus', component: ActivitiesComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }

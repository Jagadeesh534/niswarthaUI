import { Component, OnInit, ViewChild } from '@angular/core';
import { NgxSpinnerService } from 'ngx-spinner';
import { NgForm } from '@angular/forms';
import { Register } from 'src/app/shared/modals/register';
import { Entity } from 'src/app/shared/modals/entity';
import { DatePipe } from '@angular/common';
import { Title } from '@angular/platform-browser';
import Swal from 'sweetalert2';
import { BloodDonationService } from 'src/app/shared/service/blood.donation.service';
import { SpreadsheetComponent } from '@syncfusion/ej2-angular-spreadsheet';
declare let jQuery: any;
@Component({
    selector: 'app-donate',
    templateUrl: 'donateblood.component.html',
})
export class DonateBloodComponent implements OnInit {
    @ViewChild('donateForm', { static: false }) currentForm: NgForm;
    @ViewChild('spreadsheet') public spreadsheetObj: SpreadsheetComponent;
    private registerForm: NgForm;
    public register: Register;
    public formErrors;
    public validationMessages;
    public bloodGroups: Entity[] = [];
    image: string | ArrayBuffer;
    data: Object[];
    constructor(
        private spinner: NgxSpinnerService,
        private titleService: Title,
        private datePipe: DatePipe,
        private registerService: BloodDonationService) {
        this.titleService.setTitle('Register');
    }
    ngOnInit() {
        this.data = [{
            OrderID: 10248,
            CustomerID: 'VINET',
            EmployeeID: 5,
            ShipName: 'Vins et alcools Chevalier',
            ShipCity: 'Reims',
            Website: 'https://www.amazon.com/'
        },
        {
            OrderID: 10249,
            CustomerID: 'TOMSP',
            EmployeeID: 6,
            ShipName: 'Toms Spezialitäten',
            ShipCity: 'Münster',
            Website: 'https://www.overstock.com/'
        },
        {
            OrderID: 10250,
            CustomerID: 'HANAR',
            EmployeeID: 4,
            ShipName: 'Hanari Carnes',
            ShipCity: 'Rio de Janeiro',
            Website: 'https://www.aliexpress.com/'
        },
        {
            OrderID: 10251,
            CustomerID: 'VICTE',
            EmployeeID: 3,
            ShipName: 'Victuailles en stock',
            ShipCity: 'Lyon',
            Website: 'http://www.alibaba.com/'
        },
        {
            OrderID: 10252,
            CustomerID: 'SUPRD',
            EmployeeID: 4,
            ShipName: 'Suprêmes délices',
            ShipCity: 'Charleroi',
            Website: 'https://taobao.com/'
        }];
        this.register = new Register();
        this.validations();
        const today = new Date();
        this.register.lastDonatedDate = this.datePipe.transform(today, 'yyyy-MM-dd');
        this.bloodGroups = [
            { id: 'A Positive', displayValue: 'A + ve' },
            { id: 'A Positive', displayValue: 'A - ve' },
            { id: 'B Positive', displayValue: 'B + ve' },
            { id: 'B Positive', displayValue: 'B - ve' },
            { id: 'O Positive', displayValue: 'O + ve' },
            { id: 'O Positive', displayValue: 'O - ve' },
            { id: 'AB Positive', displayValue: 'AB + ve' },
            { id: 'AB Positive', displayValue: 'AB - ve' }
        ];
        this.spinner.show();
        setTimeout(() => {
            this.spinner.hide();
        }, 500);
    }
    onRegister() {
        if (!this.validateForm(this.registerForm, true)) {
            Swal.fire({
                title: '<h2>Are you sure ?</h2>',
                text: 'Do you want submit this details !',
                icon: 'warning',
                showCancelButton: true,
                confirmButtonText: 'Yes !',
                confirmButtonColor: '#13006d',
                cancelButtonText: 'No !',
                cancelButtonColor: 'red',
                reverseButtons: true
            }).then((result) => {
                if (result.value) {
                    this.spinner.show();
                    this.registerService.registerDonar(this.register).subscribe(res => {
                        if (res.success) {
                            Swal.fire(
                                '<h2>Dear ' + res.data + ',</h2>',
                                'your details has been successfully saved! Thankyou',
                                'success',
                            );
                        }
                        this.spinner.hide();
                    },
                        // tslint:disable-next-line:no-shadowed-variable
                        error => {
                            if (error) {
                                Swal.fire(
                                    '<h2>Oops,.</h2>',
                                    'Some error .. Please save your details again',
                                    'error',
                                );

                                this.spinner.hide();
                            }
                        }
                    );
                }
                this.reset();
            });
        }
    }
    reset() {
        this.register = new Register();
        this.registerForm.reset();
        this.spinner.show();
        setTimeout(() => {
            this.spinner.hide();
        }, 500);
        const today = new Date();
        this.register.lastDonatedDate = this.datePipe.transform(today, 'yyyy-MM-dd');
    }
    validations() {
        this.formErrors = {
            // tslint:disable-next-line:object-literal-key-quotes
            'type': '',
            // tslint:disable-next-line:object-literal-key-quotes
            'subtype': '',
            // tslint:disable-next-line:object-literal-key-quotes
            'requestNumber': '',
            // tslint:disable-next-line:object-literal-key-quotes
            'submittedToSoOn': '',
            // tslint:disable-next-line:object-literal-key-quotes
            'receivedToSAon': ''

        };
        this.validationMessages = {
            type: {
                required: 'please select type.'
            },
            subtype: {
                required: 'please select subtype.'
            },
            requestNumber: {
                required: 'please select Request Number.'
            },
            submittedToSoOn: {
                required: 'please select submitted to SO Date.'
            },
            receivedToSAon: {
                required: 'please select received to SA Date.'
            }
        };
    }
    validateForm(ngForm: NgForm, onSubmit: boolean = false) {

        if (!ngForm) { return; }
        const form = ngForm.form;
        let invalidForm = false;
        // tslint:disable-next-line:forin
        for (const field in this.formErrors) {
            this.formErrors[field] = '';
            const control = form.get(field);

            if (control && (control.dirty || onSubmit) && !control.valid) {
                // focus to field
                if (!invalidForm && onSubmit) {
                    jQuery('[name="' + field + '"]').focus();
                }
                invalidForm = true;
                const messages = this.validationMessages[field];
                // tslint:disable-next-line:forin
                for (const key in control.errors) {
                    this.formErrors[field] += messages[key] + ' ';
                }
            }
        }
        return invalidForm;
    }
    // tslint:disable-next-line:use-lifecycle-interface
    ngAfterViewChecked() {
        this.formChanged();
    }
    formChanged() {
        if (this.currentForm === this.registerForm) { return; }
        // supplier form
        this.registerForm = this.currentForm;
        if (this.registerForm) {
            this.registerForm.valueChanges
                .subscribe(() => this.validateForm(this.registerForm));
        }
    }
}

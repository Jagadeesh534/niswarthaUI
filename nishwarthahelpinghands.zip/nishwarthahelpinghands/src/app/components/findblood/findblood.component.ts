import { Component, OnInit } from '@angular/core';
import { NgxSpinnerService } from 'ngx-spinner';
import { Title } from '@angular/platform-browser';
import { Entity } from 'src/app/shared/modals/entity';
import { Register } from 'src/app/shared/modals/register';
import Swal from 'sweetalert2';
import { Subscription } from 'rxjs';
import { BloodDonationService } from 'src/app/shared/service/blood.donation.service';

@Component({
    selector: 'app-find',
    templateUrl: 'findblood.component.html',
})
export class FindBloodComponent implements OnInit {
    public bloodGroups: Entity[] = [];
    public bloodGroup = null;
    public error = '';
    public donarList: Register[] = [];
    public donar: Register = new Register();
    constructor(
        private spinner: NgxSpinnerService,
        private titleService: Title,
        private bloodDonationService: BloodDonationService) {
        this.titleService.setTitle('Find');
    }
    ngOnInit() {
        this.bloodGroups = [
            { id: 'A Positive', displayValue: 'A + ve' },
            { id: 'A Positive', displayValue: 'A - ve' },
            { id: 'B Positive', displayValue: 'B + ve' },
            { id: 'B Positive', displayValue: 'B - ve' },
            { id: 'O Positive', displayValue: 'O + ve' },
            { id: 'O Positive', displayValue: 'O - ve' },
            { id: 'AB Positive', displayValue: 'AB + ve' },
            { id: 'AB Positive', displayValue: 'AB - ve' }
        ];
        this.spinner.show();
        setTimeout(() => {
            this.spinner.hide();
        }, 500);

    }
    getDonarList() {

        if (this.bloodGroup === null) {
            Swal.fire('<h2>Opps</h2>', 'Select required blood group :)', 'error');
        } else {
            this.spinner.show();
            this.bloodDonationService.getDonarsList(this.bloodGroup).subscribe(res => {
                this.donarList = res;
                this.spinner.hide();
            }, error => {
                this.spinner.hide();
                Swal.fire('<h2>Opps</h2>', 'Sorry some technical Issues.', 'info');
            });
        }
    }
    resetSearch() {
        this.spinner.show();
        setTimeout(() => {
            this.spinner.hide();
        }, 500);
        this.bloodGroup = null;
        this.donarList = [];
    }
    onBloodGroupChange() {
        this.donarList = [];
    }
    getPrint() {
        this.spinner.show();
        this.bloodDonationService.printDonarList(this.bloodGroup).subscribe(res => {
            this.spinner.hide();
            const fileURL = URL.createObjectURL(res);
            window.open(fileURL, 'Blood_DonarsList.pdf');
        });
    }
}

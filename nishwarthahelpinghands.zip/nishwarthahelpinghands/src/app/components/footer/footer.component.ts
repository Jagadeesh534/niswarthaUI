import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
    selector: 'app-footer',
    templateUrl: 'footer.component.html',
})
export class FooterComponent implements OnInit {
    public navbarCollapsed = true;
    constructor(public router: Router) { }
    ngOnInit(): void {
        console.log('footer working');
    }
    goTo(id) {
        console.log(id);
        this.router.navigate(['/aboutus'], { queryParams: { controll: id } });
    }
}

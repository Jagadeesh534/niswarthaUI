import { Component, OnInit } from '@angular/core';
import { Title } from '@angular/platform-browser';
import { ActivatedRoute } from '@angular/router';
import { NgxSpinnerService } from 'ngx-spinner';
import { Activities } from 'src/app/shared/modals/activities';
import { BloodDonationService } from 'src/app/shared/service/blood.donation.service';

@Component({
    selector: 'app-activities',
    templateUrl: 'activities.component.html'
})
export class ActivitiesComponent implements OnInit {
    public images: Activities[] = [];
    public imagePath = '/assets/founder.png';
    public divId = null;
    constructor(
        private titleService: Title,
        private spinner: NgxSpinnerService,
        private activitesService: BloodDonationService,
        private activatedRoute: ActivatedRoute) {
        this.titleService.setTitle('About Us');
        this.imagePath = '/src/assets/founder.png';
        this.activatedRoute.queryParams.subscribe(res => {
            this.divId = res.controll;
            if (this.divId !== undefined && this.divId !== null) {
                this.goTo();
            }
        });
    }
    ngOnInit() {
        this.spinner.show();
        setTimeout(() => {
            this.spinner.hide();
        }, 500);
        console.log('in Activities');
    }
    goTo() {
        if (this.divId != null) {
            document.getElementById(this.divId).scrollIntoView();
        }
    }
}


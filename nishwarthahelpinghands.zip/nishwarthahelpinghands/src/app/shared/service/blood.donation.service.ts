import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Register } from '../modals/register';
import { map } from 'rxjs/operators';
import { Activities } from '../modals/activities';
import { ConfigServiceService } from 'src/config-service.service';
@Injectable({
    providedIn: 'root',
})
export class BloodDonationService {
    constructor(private http: HttpClient,
        private configService: ConfigServiceService) { }
    registerDonar(donar: Register) {
        const donarJson = {
            // tslint:disable-next-line:object-literal-key-quotes
            'id': donar.id,
            // tslint:disable-next-line:object-literal-key-quotes
            'name': donar.name,
            // tslint:disable-next-line:object-literal-key-quotes
            'bloodgroup': donar.bloodGroup,
            // tslint:disable-next-line:object-literal-key-quotes
            'age': donar.age,
            // tslint:disable-next-line:object-literal-key-quotes
            'weight': donar.weight,
            // tslint:disable-next-line:object-literal-key-quotes
            'email': donar.email,
            // tslint:disable-next-line:object-literal-key-quotes
            'address': donar.address,
            // tslint:disable-next-line:object-literal-key-quotes
            'mobilenumber': donar.mobile,
            // tslint:disable-next-line:object-literal-key-quotes
            'lastblooddonateddate': donar.lastDonatedDate,
            // tslint:disable-next-line:object-literal-key-quotes
            'gender': donar.gender,
            // tslint:disable-next-line:object-literal-key-quotes
            'image': donar.imageData
        };
        debugger
        return this.http.post(`${this.configService.getConfiguration().BASE_API_URL}/bllodDonars/save`, donarJson).
            pipe(map(response => this.mapSaveResponse(response)));
    }
    private mapSaveResponse(response) {
        const message = response.message;
        const data = response.data;
        const success = response.success;
        const res = {
            // tslint:disable-next-line:object-literal-shorthand
            message: message,
            // tslint:disable-next-line:object-literal-shorthand
            data: data,
            // tslint:disable-next-line:object-literal-shorthand
            success: success
        };
        return res;
    }
    getDonarsList(bloodGroup: string) {
        return this.http.get(`${this.configService.getConfiguration().BASE_API_URL}/bllodDonars/donarList?bloodGroup=${bloodGroup}`)
            .pipe(map(res => this.mapDonarsList(res)));
    }
    private mapDonarsList(result) {
        const donarsList: Register[] = [];
        result.data.rootProperty.forEach(d => {
            const donar = new Register();
            donar.address = d.address;
            donar.age = d.age;
            donar.bloodGroup = d.bloodgroup;
            donar.email = d.email;
            donar.gender = d.gender;
            donar.mobile = d.mobilenumber;
            donar.name = d.name;
            donar.weight = d.weight;
            donarsList.push(donar);
        });
        return donarsList;
    }
    printDonarList(bloodGroup: string) {
        return this.http.get(`${this.configService.getConfiguration().BASE_API_URL}/bllodDonars/getPdf?bloodGroup=` + bloodGroup, { responseType: 'blob' })
            .pipe(map((res => {
                return new Blob([res], { type: 'application/pdf' });
            })));
    }

    getActivities() {
        return this.http.get(`http://nhhapi-env.eba-m6faya33.us-east-2.elasticbeanstalk.com/bllodDonars/getActivities`)
            .pipe(map(res => this.convertToImageSrc(res)));
    }
    private convertToImageSrc(response) {
        debugger
        const images: Activities[] = [];
        response.data.rootProperty.forEach(i => {
            const image = new Activities();
            image.imageSrc = i.imageSrc;
            image.title = i.title;
            images.push(image);
        });
        return images;
    }
}

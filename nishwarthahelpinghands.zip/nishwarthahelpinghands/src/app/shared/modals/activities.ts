export class Activities {
    constructor(
        public title: string = null,
        public imageSrc: string = null
    ) {
    }
}

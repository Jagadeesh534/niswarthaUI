export class Register {
    constructor(
        public id: string = null,
        public name: string = null,
        public bloodGroup: string = null,
        public age: number = null,
        public weight: number = null,
        public email: string = null,
        public mobile: string = null,
        public address: string = null,
        public gender: string = null,
        public lastDonatedDate: string = null,
        public imageData: any = null
    ) { }
}

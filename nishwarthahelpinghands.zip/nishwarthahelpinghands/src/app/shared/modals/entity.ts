export class Entity {
    constructor(
        public id: string = null,
        public displayValue: string = null
    ) {
    }
}

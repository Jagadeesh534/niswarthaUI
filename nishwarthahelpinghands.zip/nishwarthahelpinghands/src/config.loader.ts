
import { environment } from './environments/environment';
import { ConfigServiceService } from './config-service.service';

export function ConfigLoader(configService: ConfigServiceService) {

    return () => configService.load(environment.configFile);
}

export class Configuration {
    constructor(public BASE_API_URL: string) {
    }

}